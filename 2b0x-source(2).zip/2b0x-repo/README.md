# 2B0X — Virtual OS Launcher

**v2.0 (Public)** &nbsp;\u00b7&nbsp; Copyright (c) 2026 2B0X Corporation

A VirtualBox-style desktop app for Linux that runs OS images — ISO files,
ZIP archives, or plain folders — as real, sandboxed virtual machines using
QEMU/KVM.

## Features

- **Upload** an ISO / ZIP / folder — 2B0X packages it into a bootable image
- **Try** it instantly in a throwaway session — nothing is kept once you close it
- **Install** it to create a permanent, persistent virtual machine — everything
  you do inside it (installs, files, settings) is saved for next time
- **Installed** tab — relaunch any installed system, or **Delete** it to wipe
  its virtual disk and files completely
- **History** tab — a log of everything you've tried or launched
- A 10-second animated splash (with sound) plays when the app starts —
  click "Skip" to jump straight in
- Small "v2.0 \u00b7 \u00a9 2026 2B0X Corporation" watermark in the corner of the Home page
- Fully resizable window; every action is wrapped so a failure shows a dialog
  instead of crashing the app

### Sandboxing

Each virtual machine is a real, isolated QEMU guest:

- **No host filesystem access** — the guest only ever sees the exact ISO and
  virtual disk 2B0X hands it. There's no shared/virtfs folder wired up, so it
  cannot read or write anything else on your Linux system.
- **Internet access still works** — QEMU's built-in user-mode network device
  gives the guest outbound internet (DHCP + NAT) without exposing your LAN
  or files.
- Files you pick on the host (like the ISO you upload) are read by 2B0X
  itself to build the VM, which is normal — that's not the same as the
  *guest OS* having host access.

### Where your data lives

2B0X creates a plain folder in your home directory — `~/2b0x` — so you can
browse it in any file manager:

```
~/2b0x/
  systems/
    <your-os-name>-xxxxxx/
      system.json     metadata (name, type, install date, last launched)
      source.iso       the bootable image
      disk.qcow2       the persistent virtual hard disk — this is what
                        "saves your progress" between launches
      apps/            your own notes/reference folder for this system
                        (not shared into the VM — see sandboxing above)
  history.json         log of everything you've tried/launched
  .tmp/                scratch space for "Try" sessions, cleaned up
                        automatically after the VM closes
```

Deleting a system from the Installed tab removes its entire folder — disk,
ISO, and all.

## Requirements

- Ubuntu/Debian-based Linux
- `python3-gi`, `gir1.2-gtk-3.0` (GTK3 UI)
- `qemu-system-x86`, `qemu-utils` (virtualization backend)
- `genisoimage` (packages folders/zips into bootable ISOs)
- `pulseaudio-utils` or `alsa-utils` for the boot chime (optional — the app
  runs fine without it, just silently)
- `/dev/kvm` for hardware acceleration (optional but recommended)

All required dependencies are declared in `debian/control` and installed
automatically by `apt` when you install the `.deb`.

## Install

Grab a built `.deb` from [Releases](../../releases), or build it yourself:

```bash
git clone <this-repo-url>
cd 2b0x
./build.sh
sudo apt install ./2b0x_2.0.deb
```

Launch **2B0X** from your applications menu, or run `2b0x` from a terminal.

## Uninstall

```bash
sudo apt remove 2b0x
```

Your `~/2b0x` folder (installed systems, history) is **not** removed
automatically, so reinstalling later picks up where you left off. To wipe
everything:

```bash
rm -rf ~/2b0x
```

## Repo layout

```
src/2b0x            the application (single Python/GTK3 script)
data/2b0x.desktop   desktop entry
data/icons/         app icon at multiple sizes
data/sounds/        boot chime WAV played on app startup
debian/control      package metadata / dependencies
debian/postinst     post-install hook (icon cache, desktop DB refresh)
build.sh            builds the .deb from the above
```

## Known limitations

- Booting an OS from a folder or ZIP works by packaging it into an ISO on
  the fly (`genisoimage`) — it can't make an arbitrary folder of files
  bootable if there's nothing bootable in it.
- The QEMU backend here targets x86/x86_64 guests. ARM-based OS images
  (e.g. phone/tablet builds of Android/LineageOS) need
  `qemu-system-aarch64` with a different machine setup — not wired up in
  this version.
- No custom in-guest boot splash — that's controlled by the guest OS itself,
  not the hypervisor. 2B0X's own splash plays at app startup instead.
- No automatic update checking against GitHub Releases — this was
  intentionally left out; the version/copyright shown is a static watermark.

## License

MIT — see `LICENSE`.
