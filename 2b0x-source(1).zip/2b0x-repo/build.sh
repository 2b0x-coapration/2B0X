#!/bin/bash
# Builds 2b0x_<version>.deb from the source in this repo.
# Usage: ./build.sh

set -e

VERSION="2.0"
NAME="2b0x"
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_DIR="$ROOT_DIR/pkg/${NAME}_${VERSION}"

echo "==> Cleaning previous build"
rm -rf "$ROOT_DIR/pkg"
mkdir -p "$PKG_DIR/DEBIAN" \
         "$PKG_DIR/usr/bin" \
         "$PKG_DIR/usr/share/2b0x" \
         "$PKG_DIR/usr/share/applications" \
         "$PKG_DIR/usr/share/icons/hicolor/16x16/apps" \
         "$PKG_DIR/usr/share/icons/hicolor/32x32/apps" \
         "$PKG_DIR/usr/share/icons/hicolor/48x48/apps" \
         "$PKG_DIR/usr/share/icons/hicolor/64x64/apps" \
         "$PKG_DIR/usr/share/icons/hicolor/128x128/apps" \
         "$PKG_DIR/usr/share/icons/hicolor/256x256/apps"

echo "==> Copying application"
cp "$ROOT_DIR/src/2b0x" "$PKG_DIR/usr/bin/2b0x"
chmod 755 "$PKG_DIR/usr/bin/2b0x"

echo "==> Copying boot sound"
cp "$ROOT_DIR/data/sounds/boot.wav" "$PKG_DIR/usr/share/2b0x/boot.wav"

echo "==> Copying desktop entry + icons"
cp "$ROOT_DIR/data/2b0x.desktop" "$PKG_DIR/usr/share/applications/2b0x.desktop"
cp "$ROOT_DIR/data/icons/2b0x-16.png"  "$PKG_DIR/usr/share/icons/hicolor/16x16/apps/2b0x.png"
cp "$ROOT_DIR/data/icons/2b0x-32.png"  "$PKG_DIR/usr/share/icons/hicolor/32x32/apps/2b0x.png"
cp "$ROOT_DIR/data/icons/2b0x-48.png"  "$PKG_DIR/usr/share/icons/hicolor/48x48/apps/2b0x.png"
cp "$ROOT_DIR/data/icons/2b0x-64.png"  "$PKG_DIR/usr/share/icons/hicolor/64x64/apps/2b0x.png"
cp "$ROOT_DIR/data/icons/2b0x-128.png" "$PKG_DIR/usr/share/icons/hicolor/128x128/apps/2b0x.png"
cp "$ROOT_DIR/data/icons/2b0x-256.png" "$PKG_DIR/usr/share/icons/hicolor/256x256/apps/2b0x.png"

echo "==> Copying Debian control files"
cp "$ROOT_DIR/debian/control" "$PKG_DIR/DEBIAN/control"
cp "$ROOT_DIR/debian/postinst" "$PKG_DIR/DEBIAN/postinst"
chmod 755 "$PKG_DIR/DEBIAN/postinst"

echo "==> Fixing permissions"
find "$PKG_DIR" -type d -exec chmod 755 {} \;
find "$PKG_DIR/usr/share" -type f -exec chmod 644 {} \;
chmod 644 "$PKG_DIR/usr/share/2b0x/boot.wav"
chmod 755 "$PKG_DIR/usr/bin/2b0x"
chmod 755 "$PKG_DIR/DEBIAN/postinst"

echo "==> Building .deb"
dpkg-deb --root-owner-group --build "$PKG_DIR" "$ROOT_DIR/${NAME}_${VERSION}.deb"

echo ""
echo "Done: $ROOT_DIR/${NAME}_${VERSION}.deb"
echo "Install with: sudo apt install ./${NAME}_${VERSION}.deb"
