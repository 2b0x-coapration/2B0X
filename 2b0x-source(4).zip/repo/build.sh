#!/bin/sh
# Rebuilds the 2B0X .deb package from this repo's layout.
# Usage: ./build.sh
set -e

VERSION=$(grep -m1 '^Version:' DEBIAN/control | awk '{print $2}')
OUT="2b0x_${VERSION}_all.deb"

chmod +x usr/bin/2b0x
chmod +x DEBIAN/postinst

dpkg-deb --build --root-owner-group . "$OUT" 2>/dev/null \
    || dpkg-deb --build . "$OUT"

echo "Built $OUT"
