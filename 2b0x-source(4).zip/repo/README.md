# 2B0X

2B0X is a desktop app for launching OS images as sandboxed QEMU virtual
machines, and running Windows `.exe` files via Wine.

## Layout

This repo is laid out as a Debian package tree, so it builds directly
with `dpkg-deb`:

```
DEBIAN/
  control        — package metadata (name, version, dependencies)
  postinst       — post-install hook (icon cache, desktop database)
usr/
  bin/2b0x                         — the app itself (Python 3 + GTK 3)
  share/2b0x/boot.wav              — boot sound
  share/applications/2b0x.desktop  — desktop launcher entry
  share/icons/hicolor/…/2b0x.png   — app icon, multiple sizes
```

## Build

```sh
./build.sh
```

This produces `2b0x_<version>_all.deb` in the repo root.

## Install

```sh
sudo apt install ./2b0x_*_all.deb
```

### Dependencies

- `python3` (>= 3.6), `python3-gi`, `gir1.2-gtk-3.0`
- `qemu-system-x86`, `qemu-utils`, `genisoimage`
- Recommended: `qemu-kvm` (hardware acceleration), `wine` (for the EXE
  runner), `pulseaudio-utils` or `alsa-utils` (boot sound)

## Run

Launch **2B0X** from your application menu, or run `2b0x` from a
terminal. The splash screen offers:

- **Launch** — jumps straight into the last installed system
- **OS Manager** — opens the full manager (upload an OS, Installed
  systems, launch history, settings)
